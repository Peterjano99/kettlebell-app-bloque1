Kettlebell 30' — Bloque 1 (PWA)
===============================

Qué es:
- App tipo PWA (se instala en Android/tablet) con timer 40/20, días A-B-C-D, pesos editables y "Hecho".

Instalación (Android / Tablet):
1) Sube estos archivos a un hosting estático (recomendado: Netlify o GitHub Pages).
2) Abre la URL en Chrome.
3) Menú (⋮) -> "Instalar aplicación" o "Agregar a pantalla principal".

Importante:
- Para que se pueda instalar como app, debe estar en HTTPS (hosting) o en localhost.

Ajuste de pesos:
- Botón “Mis pesos” -> + / -.
- Se guarda en el dispositivo (localStorage).

Actualización por bloques:
- Para Bloque 2 y 3 se reemplaza config.json (y opcionalmente título).